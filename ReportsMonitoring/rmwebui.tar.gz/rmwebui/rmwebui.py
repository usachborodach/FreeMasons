from flask import Flask
import json, os, base64, requests
from flask import render_template, request
Config = json.loads(base64.b64decode(json.loads((requests.get("http://localhost:8500/v1/kv/tools/ReportsMonitoring")).text)[0]["Value"]).decode("utf-8"))
app = Flask(__name__)

print("SecondTestMessage!")

@app.route("/", methods=["GET"])
def IndexPage():
    Data = list()
    FilesList = sorted(os.listdir(Config["DataPath"]))
    for FileName in reversed(FilesList):
        Data.append(json.loads(open(os.path.join(Config["DataPath"], FileName), encoding="utf-8").read()))
    return render_template("index.html", Data = Data, Datacenter=Config["Datacenter"])

app.run(debug=True, host=Config["Host"], port=Config["Port"])